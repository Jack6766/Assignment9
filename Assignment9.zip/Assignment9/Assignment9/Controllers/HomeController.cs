﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Assignment9.Models;

namespace Assignment9.Controllers
{
    public class HomeController : Controller
    {
        //The context file
        private MoviesDbContext context { get; set; }

        //creates a new object of a movie, this allows us to edit the movie
        private static ApplicationResponse? movieToDelete { get; set; }

        //we set to true when we want to edit a movie
        private static bool fromEdit { get; set; } = false;

        public HomeController(MoviesDbContext con)
        {
            context = con;
        }

        [HttpGet]
        public IActionResult MovieApplication()
        {
            return View();
        }

        [HttpPost]
        public IActionResult MovieApplication(ApplicationResponse appResponse)
        {
            if (ModelState.IsValid)
            {
                //if edit is true then it goes in and deletes the movie object
                // also allows us to use the same page as adding a new movie 
                if (fromEdit == true)
                {
                    context.movies.Remove(movieToDelete);
                    context.SaveChanges();
                }

                //adds the new or edited movie to the database 
                context.movies.Add(appResponse);
                context.SaveChanges();

                //sets it back to false
                fromEdit = false;
                movieToDelete = null; //deletes the movie object 
                return View("Confirmation", appResponse);
            }
            else
            {
                return View();
            }
        }

        //deletes a movie and saves the changes 
        public IActionResult RemoveMovie(ApplicationResponse movie)
        {
            context.movies.Remove(movie);
            context.SaveChanges();
            return View("MovieCollection", context.movies);
        }

        //edit movie allows for users to edit the movie and copies the movie they want to edit
        public IActionResult EditMovie(ApplicationResponse movie)
        {
            fromEdit = true;
            movieToDelete = movie;
            return View("MovieApplication", movie);
        }

        public IActionResult movieCollection()
        {
            return View(context.movies.Where(r => r.Title != "Independence Day"));
        }

        [HttpGet]
        public IActionResult Podcasts()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
