﻿using System;
using Microsoft.EntityFrameworkCore;

namespace Assignment9.Models
{
    public class MoviesDbContext : DbContext
    {
        public MoviesDbContext(DbContextOptions<MoviesDbContext> options) : base(options)
        {

        }

        public DbSet<ApplicationResponse> movies { get; set; } //creates the movie objects
    }
}
